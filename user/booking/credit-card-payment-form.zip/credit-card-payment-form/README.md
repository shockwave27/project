# Credit Card Payment Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/John-Prasad/pen/gOqaXVV](https://codepen.io/John-Prasad/pen/gOqaXVV).

Wanted to work with some masking so made a payment form so, using vanilla JS and the imask.js library, made a fairly simply payment form that uses regex patterns to detect the credit card type as the user is inputting values and properly applies the relevant spacing associated with that brand.  Also wanted to do a smidge of style flair so made a simple SVG card that changes as the user fills out the form.